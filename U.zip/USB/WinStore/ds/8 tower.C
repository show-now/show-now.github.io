#include <stdio.h>
#include <conio.h>

void tower(int num, char from, char top, char aux){
	if(num == 1){
		printf("Move disk 1 from peg %c top peg %c\n", from, top);
		return;
	}
	tower(num-1, from, aux, top);
	printf("Move disk %d form peg %c to top peg %c\n", num, from, top);
	tower(num-1, aux, from, top);
}

void main(){
	int num;
	clrscr();
	printf("Enter the nubmer of disks: ");
	scanf("%d", &num);
	printf("\nThe sequence of moves involver of Hanoi are: \n");
	tower(num, 'A', 'B', 'C');
	getch();
}