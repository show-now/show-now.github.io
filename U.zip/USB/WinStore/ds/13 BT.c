#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

struct Node {
    int data;
    struct Node* left;
    struct Node* right;
};

struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

struct Node* insert(struct Node* root, int data) {
    if (root == NULL)
        return createNode(data);

    if (data < root->data)
        root->left = insert(root->left, data);
    else if (data > root->data)
        root->right = insert(root->right, data);

    return root;
}

struct Node* findMin(struct Node* root) {
    while (root->left != NULL)
        root = root->left;
    return root;
}

struct Node* deleteNode(struct Node* root, int data) {
    struct Node* temp;

    if (root == NULL)
        return root;

    if (data < root->data)
        root->left = deleteNode(root->left, data);
    else if (data > root->data)
        root->right = deleteNode(root->right, data);
    else {
        if (root->left == NULL && root->right == NULL) {
            free(root);
            return NULL;
        } else if (root->left == NULL) {
            temp = root->right;
            free(root);
            return temp;
        } else if (root->right == NULL) {
            temp = root->left;
            free(root);
            return temp;
        } else {
            temp = findMin(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right, temp->data);
        }
    }
    return root;
}

void inorderTraversal(struct Node* root) {
    if (root != NULL) {
        inorderTraversal(root->left);
        printf("%d ", root->data);
        inorderTraversal(root->right);
    }
}

void main() {
    struct Node* root = NULL;
    int i;
    int elements[] = {18, 15, 40, 50, 30, 17, 41};
    int n = sizeof(elements) / sizeof(elements[0]);

    clrscr();

    for (i = 0; i < n; i++)
        root = insert(root, elements[i]);

    printf("Tree after creation: ");
    inorderTraversal(root);
    printf("\n");

    printf("Inserting 45 into the tree: ");
    root = insert(root, 45);
    inorderTraversal(root);
    printf("\n");

    printf("Inserting 19 into the tree: ");
    root = insert(root, 19);
    inorderTraversal(root);
    printf("\n");

    printf("Deleting 15 from the tree: ");
    root = deleteNode(root, 15);
    inorderTraversal(root);
    printf("\n");

    printf("Deleting 17 from the tree: ");
    root = deleteNode(root, 17);
    inorderTraversal(root);
    printf("\n");

    printf("Deleting 41 from the tree: ");
    root = deleteNode(root, 41);
    inorderTraversal(root);
    printf("\n");

    getch();
}