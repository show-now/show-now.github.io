#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#define N 10

int QUEUE[N];
int FRONT = -1, REAR = -1;
int ITEM;

void cQinsert() {
    if ((FRONT == (REAR + 1) % N)) {
        printf("\nQueue Overflow");
    } else {
        printf("\nEnter the element to be inserted: ");
        scanf("%d", &ITEM);

        if (FRONT == -1) {
            FRONT = REAR = 0;
        } else {
            REAR = (REAR + 1) % N;
        }

        QUEUE[REAR] = ITEM;
    }
}

void cQdelete() {
    if (FRONT == -1) {
        printf("\nQueue Underflow!!");
    } else {
        printf("\nThe deleted item is: %d", QUEUE[FRONT]);

        if (FRONT == REAR) {
            FRONT = REAR = -1;
        } else {
            FRONT = (FRONT + 1) % N;
        }
    }
}

void cQdisplay() {
    int i;
    if (FRONT == -1) {
        printf("\nNo elements in the Queue");
    } else {
        printf("\nCircular Queue: ");

        if (FRONT <= REAR) {
            for (i = FRONT; i <= REAR; i++) {
                printf("%d ", QUEUE[i]);
            }
        } else {
            for (i = FRONT; i < N; i++) {
                printf("%d ", QUEUE[i]);
            }
            for (i = 0; i <= REAR; i++) {
                printf("%d ", QUEUE[i]);
            }
        }

        printf("\nFront element of the queue is: %d", QUEUE[FRONT]);
        printf("\nRear element of the queue is: %d\n", QUEUE[REAR]);
    }
}

void main() {
    int ch;

    clrscr();

    while (1) {
        printf("\n\n\tCIRCULAR QUEUE IMPLEMENTATION USING ARRAY");
        printf("\n1. Insert");
        printf("\n2. Delete");
        printf("\n3. Display");
        printf("\n4. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                cQinsert();
                break;
            case 2:
                cQdelete();
                break;
            case 3:
                cQdisplay();
                break;
            case 4:
                exit(0);
            default:
                printf("\nInvalid input");
        }
    }

    getch();
}
