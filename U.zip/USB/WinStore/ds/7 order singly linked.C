#include<stdio.h>
#include<conio.h>

typedef struct node{
	int info;
	struct node *link;
}NODE;

NODE *header;

void CREATE_HEADER(){
	header=(NODE*)malloc (sizeof(NODE));
	header->info=0;
	header->link=NULL;
}

void INSERT_ORDERLIST(int item){
	NODE *NEWNODE, *PREVPTR, *CURPTR;

	NEWNODE=(NODE*)malloc(sizeof(NODE));
	NEWNODE->info=item;
	NEWNODE->link=NULL;

	if(header->link == NULL){
		header->link=NEWNODE;
	}
	else if(item < header->info){
		NEWNODE->link=header;
		header=NEWNODE;
	}
	else{
		PREVPTR=header;
		CURPTR=header->link;

		while(CURPTR!=NULL && item>CURPTR->info){
			PREVPTR=CURPTR;
			CURPTR=CURPTR->link;
		}

		PREVPTR->link=NEWNODE;
		NEWNODE->link=CURPTR;
	}
}

void DISPLAY_NODE(){
	NODE *CURPTR;
	CURPTR = header->link;

	printf("\nLIST: ");
	while(CURPTR!=NULL){
		printf("%d->",CURPTR->info);
		CURPTR=CURPTR->link;
	}
}

void DELETE_NODE(int item){
	NODE *PREVPTR, *CURPTR;
	PREVPTR = header;
	CURPTR = header->link;

	if(item==header->info){
		header=CURPTR;
		free(PREVPTR);
	}
	else{
		while(CURPTR!=NULL && CURPTR->info!=item){
			PREVPTR=CURPTR;
			CURPTR=CURPTR->link;
		}

		if(CURPTR!=NULL){
			PREVPTR->link=CURPTR->link;
			free(CURPTR);
		}
		else{
			printf("\nData not found");
		}
	}
}

void main(){
	clrscr();
	CREATE_HEADER();

	printf("\n***INSERTING 61,16,8,27:***");
	INSERT_ORDERLIST(61);
	DISPLAY_NODE();

	INSERT_ORDERLIST(16);
	DISPLAY_NODE();

	INSERT_ORDERLIST(8);
	DISPLAY_NODE();

	INSERT_ORDERLIST(27);
	DISPLAY_NODE();

	printf("\n ***DELETE 8,61,27:***");
	DELETE_NODE(8);
	DISPLAY_NODE();

	DELETE_NODE(61);
	DISPLAY_NODE();

	DELETE_NODE(27);
	DISPLAY_NODE();

	getch();
}